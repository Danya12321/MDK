package com.example.pr_9_vasilev_d_pr_21_101;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class web extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
    }
}